<?php 
class Newsman_Client_Exception extends Exception
{
	
}
?>