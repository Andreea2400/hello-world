-------------------------------------------------------
=====================================================
Module: Newsman Newsletter Sync - Customers import
Author: TeamWeb

E-mail: razvan@teamweb.ro

Website: http://teamweb.ro

=======================================================
======================= INSTALL =======================
-------------------------------------------------------

Installation Steps:
1.  Extract the zip file which you downloaded now
2.  Copy contents of the upload folder and paste to your opencart root directory
3.	Give priveleges to your user in admin->System->Users->User Groups
4.  Go to admin->Extensions->Modules and then install Newsman Newsletter Sync module
5.  After installation edit the Newsman Newsletter Sync module
6.  If you don't have a Newsman account, register one at https://ssl.newsman.ro/
7.  After registration, Newsman User ID and API Key will be available in your account
8.  Enter  User ID and API Key in the form and click on Connect button
9.  Now your lists from newsman are available for selection in the dropdown. Select a list and click on Save button
10. Select the import type
11. Click on Manual sync button to stat syncing
12. Wait to finish and you will be redirected to the first page

Note: 
	CURL must be enabled on webserver.
	VQMOD Must be installed.

======================= FEEDBACK ======================
-------------------------------------------------------
Thanks for your purchase. 
In case of any doubt or any suggestion don�t be shy, get in touch. Send us an email at razvan@teamweb.ro
Your feedback and reviews are welcome & gratefully received. 

Thanks, 
TeamWeb
